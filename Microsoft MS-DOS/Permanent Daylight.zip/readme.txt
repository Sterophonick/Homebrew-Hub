*** P e r m a n e n t  Daylight ***
*** by Intoxicated Little Bunny ***

DOS version

This readme doesn't contain much, just some explanations and trouble shooting.

How to play:

Ever played old Sierra adventure games? Well this game works the same way! If you move to the top of the screen you'll see a GUI with the controls

- The walking man makes the player walk to were you click.
- The eye makes the player look at things
- With the hand can you pick up and interact with things (open doors etc)
- With the ballon can you speak to things.
- You carry all items you pick up in the pocket.

Troubleshooting:

- The game works slow - if you're running it on 640*480 res, use 320*240 instead.

- The game doesn't work or chrashes - mail me.. it's probably a scripting bug

- I can't comlete it - do you think I'm putting up a walkthrough here?! 
Type your problems at the AGS-forum or mail me.

That's it.. happy playing and watch for the killer bunnies...

//Linus Larsson aka 2ma2 ilb@notrix.net
- 