Argon
A game for the XNA platform (PC / XBox 360)


Introduction
============
Argon is a robotron like shooter game. One stick steers the ship,
the other sticks controls the shooting direction. Try to score as
many points as possible.


Installation
============
XNA FX 2.0 is required. For PC, first run the "DX Redist\DXSETUP.exe"
file. This must be done even if you have a previously installed DirectX.
Then run "XNA FX Redist\xnafx20_redist.msi". Microsoft .NET 2.0 or newer
is also required (most systems already have this; it can be installed
from Windows Update).

For the XBox 360, you need to setup the XNA environment. See 
http://creators.xna.com/ for more information.

If you want to run the PC version in a window, start the program with the
"-windowed" command line parameter.


Controls
========
Control the ship with a 360 controller. The left stick controls the
ship, the right stick controls the shooting. When you kill enemies,
the level behind it gains "energy". When there's enough energy near
you, the bomb icon will turn yellow in the upper left corner. You
can use both triggers to use a bomb at this location. This will drain
the energy from the level.

On PC, you can also play with the keyboard and mouse. Use directional
keys to move the ship and use the mouse to aim (left mouse button
shoots). Right mouse button or space uses a bomb if one can be used at
the current location.


Contact
=======
http://www.xmunkki.org/


Credits
=======
Development team:
  Jere "XMunkki" Sanisalo
  Kimmo Lahtinen
  Tomi Turunen

Greetings:
  Dibhda
  tAAt
  static
  Kloonigames
  Mayoneez



Version history
===============
28.07.2008: == Second compo update ==
 - Major refactoring
 - Sounds, rumble added
 - New enemy types
 - New bomb/powerup/multiplier mechanic
 - Loads of little additions, tweaks

21.07.2008:
 - Minor improvements, bombs

20.07.2008: == First compo version ==
